<h2>How it works:</h2>

<p>1- Function caesar_cipher: This function takes the text, the shift value, and the mode (either 'encrypt' or 'decrypt'). It shifts each alphabetical character by the shift value, wrapping around the alphabet if necessary. Non-alphabetical characters remain unchanged.</p>
<p>2- Function main: This is the main function where the user is prompted to input the mode (encrypt or decrypt), the message, and the shift value. It then calls the caesar_cipher function with the provided inputs and displays the result.</p>

<h2>Usage:</h2>

<p>1- Run the program.</p>
<p>2- Enter the message you want to encrypt or decrypt.</p>
<p>3- Enter the shift value (an integer).</p>
